export class Page {
    id: number;
    title: string;
    description: string;
}
